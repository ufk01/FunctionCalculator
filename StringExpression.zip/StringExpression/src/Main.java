import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Please enter MathExpression.\nIf there are two parentheses next to each other,\nput an asterisk ==> )*( between them. \nExample = 6*(4/2+3)*(5+2*3)+4-1");
		String mathExp= keyboard.nextLine();              //6*(4/2)+3*1
		List<String> arr = new ArrayList<String>();
		String finalResult = "", temp = "";
		arr = Exp(mathExp.trim(), arr);
		for (int i = 0; i < arr.size(); i++) {
			if (arr.get(i).charAt(0) == '(') {
				temp = arr.get(i);
				String resultPr = CalculationOfPr1(temp.substring(1, temp.length() - 1));
				arr.set(i, resultPr);
				temp = "";
			}
		}
		for (int i = 0; i < arr.size(); i++) {
			temp += arr.get(i);
		}
		finalResult = CalculationOfPr1(temp);
		System.out.println("Result = " + finalResult);
	}

	public static List<String> Exp(String exp, List<String> arr) {
		String temp = "";
		for (int i = 0; i < exp.length(); i++) {

			switch (exp.charAt(i)) {
			case '+':
				if (temp != "")
					arr.add(temp);
				temp = "";
				arr.add(Character.toString(exp.charAt(i)));
				break;
			case '-':
				if (temp != "")
					arr.add(temp);
				temp = "";
				arr.add(Character.toString(exp.charAt(i)));
				break;
			case '/':
				if (temp != "")
					arr.add(temp);
				temp = "";
				arr.add(Character.toString(exp.charAt(i)));
				break;
			case '*':
				if (temp != "")
					arr.add(temp);
				temp = "";
				arr.add(Character.toString(exp.charAt(i)));
				break;
			case '(':
				while (exp.charAt(i) != ')') {
					temp += exp.charAt(i);
					i++;
				}
				temp += exp.charAt(i);
				arr.add(temp);
				temp = "";
				break;
			}
			if (Character.isDigit(exp.charAt(i))) {
				temp += exp.charAt(i);
				if (i == exp.length() - 1) {
					arr.add(temp);
				}
			}
		}

		return arr;
	}

	public static String CalculationOfPr1(String pr) {
		String temp1 = "", temp2 = "";
		String[] arr = pr.split("");
		int left = 0, right = 0;
		char exp = '\0';
		int result = 0;
		for (int i = 1; i < arr.length - 1; i++) {
			if (arr[i].trim() == "_") {
				continue;
			}
			if (arr[i].equals("*") || arr[i].equals("/")) {
				exp = arr[i].charAt(0);
				arr[i] = "_";
				left = i - 1;
				right = i + 1;
				while ((Character.isDigit(arr[left].charAt(0))) || arr[left] == "_") {
					if (arr[left].equals("_")) {
						left--;
						if (left < 0) {
							break;
						}
						continue;
					}
					temp1 += arr[left];
					arr[left] = "_";
					left--;
					if (left < 0) {
						break;
					}

				}
				while ((Character.isDigit(arr[right].charAt(0))) || arr[right] == "_") {
					if (arr[right].equals("_")) {
						right++;
						if (right == arr.length) {
							break;
						}
						continue;
					}
					temp2 += arr[right];
					arr[right] = "_";
					right++;
					if (right == arr.length) {
						break;
					}

				}
				result = FindingNumbers(temp1, exp, temp2);
				arr[i - 1] = Integer.toString(result);
				temp1 = temp2 = "";
			}

		}

		arr = CalculationOfPr2(arr, pr);
		return arr[0];
	}

	public static String[] CalculationOfPr2(String[] arr, String pr) {
		String temp1 = "", temp2 = "";
		int left = 0, right = 0;
		char exp = '\0';
		int result = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i].equals("_")) {
				continue;
			}
			if (arr[i].equals("+") || arr[i].equals("-")) {
				exp = arr[i].charAt(0);
				arr[i] = "_";
				left = i - 1;
				right = i + 1;
				while ((Character.isDigit(arr[left].charAt(0))) || arr[left].equals("_")) {
					if (arr[left].equals("_")) {
						left--;
						if (left < 0) {
							break;
						}
						continue;
					}
					temp1 += arr[left];
					arr[left] = "_";
					left--;
					if (left < 0) {
						break;
					}
				}
				while ((Character.isDigit(arr[right].charAt(0))) || arr[right].equals("_")) {
					if (arr[right].equals("_")) {
						right++;
						if (right == arr.length) {
							break;
						}
						continue;
					}
					temp2 += arr[right];
					arr[right] = "_";
					right++;
					if (right == arr.length) {
						break;
					}
				}
				result = FindingNumbers(temp1, exp, temp2);
				arr[i - 1] = Integer.toString(result);
				temp1 = temp2 = "";

			}
		}
		for (int i = 0; i < arr.length; i++) {
			if(Character.isDigit(arr[0].charAt(0))) {
				return arr;
			}
			else if(Character.isDigit(arr[i].charAt(0))) {
				arr[0] = arr[i];
				arr[i] = "-";
				break;
			}
		}
		return arr;
	}

	public static double FindingLastNumbers(List<String> arr) { // Son olarak ana i�lem yap�lacak (�rnek: 6*10)
		double result = 0.0;

		return result;
	}

	public static int FindingNumbers(String temp1, char exp, String temp2) {
		int result = 0;
		switch (exp) {
		case '+':
			result = Integer.parseInt(temp1) + Integer.parseInt(temp2);
			break;
		case '-':
			result = Integer.parseInt(temp1) - Integer.parseInt(temp2);
			break;
		case '/':
			result = Integer.parseInt(temp1) / Integer.parseInt(temp2);
			break;
		case '*':
			result = Integer.parseInt(temp1) * Integer.parseInt(temp2);
			break;

		}
		return result;

	}

}
